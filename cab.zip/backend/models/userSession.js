class UserSession {
    constructor() {
        this.state = 'IDLE';
        this.userData = {};
    }
}

module.exports = UserSession;
